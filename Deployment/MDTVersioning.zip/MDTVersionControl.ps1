﻿# *************************************************************************** 
# 
# File:      MDTVersionControl.ps1 
# 
# Authors:   Rens Hollanders rens.hollanders (@) gmail.com
#            Pascal Zeptner
# 
# Purpose:   This PowerShell script will query, create and duplicate task
#            sequences, in order to provide versioning within MDT
#            
#            Note that there should be no users actively adding items to the 
#            deployment share while running this script, as some of the 
#            operations performed could cause these items to be lost. 
# 
#            This requires PowerShell 2.0 CTP3 or later. 
# 
# Usage:     Copy this file to an appropriate location.  Edit the file to 
#            change the variables below.
#
# Version:   v1.0
#
#
# Support:   This script supports MDT v2012update1 and MDT v2013
#
#
# 
# ------------- DISCLAIMER -------------------------------------------------- 
# This script code is provided as is with no guarantee or warranty concerning 
# the usability or impact on systems and may be used, distributed, and 
# modified in any way provided the parties agree and acknowledge the 
# Microsoft or Microsoft Partners have neither accountability or 
# responsibility for results produced by use of this script. 
# 
# Microsoft will not provide any support through any means. 
# ------------- DISCLAIMER -------------------------------------------------- 
# 
# **************************************************************************

# Check for elevation
If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
    [Security.Principal.WindowsBuiltInRole] "Administrator"))
{
    Write-Warning "You need to run this script from an elevated PowerShell prompt!`nPlease start the PowerShell prompt as an Administrator and re-run the script."
    Write-Warning "Aborting script..."
    Break
}

# Static Variables
$PSDrive = "DS001:"
$PhysicalPath = "D:\DeploymentShare"
$Hostname = "WIN2012R2-MDT03"
$ShareName = "DeploymentShare$"
$UNCPath = "\\$Hostname\$Sharename"
$Description = "Deployment Share"
$TSFolder = "Task Sequences\Build" # "Task Sequences\Deploy"
$TSTemplate = "Client.xml" # "Server.xml" ; "Custom.xml"

# Import the Microsoft Deployment Toolkit Powershell Module
If (Test-Path "C:\Program Files\Microsoft Deployment Toolkit\bin\MicrosoftDeploymentToolkit.psd1") { Write-Host "MDT PowerShell Module was found, continuing script .." -nonewline -ForegroundColor Green
    Import-Module "C:\Program Files\Microsoft Deployment Toolkit\bin\MicrosoftDeploymentToolkit.psd1"
}

Else {
    Write-Warning "MDT PowerShell Module was not found, aborting script .."
    Break
}

# Create Powershell Drive
If (-NOT (Test-Path $PSDrive)) {
    New-PSDrive -Name ($PSdrive -replace(":","")) -PSProvider MDTProvider -Root "$PhysicalPath" -Description "$Description" -NetworkPath "$UNCPath" | add-MDTPersistentDrive
}

# Get Selected Task Sequence Properties
$TSProperty = Get-ChildItem "$PSDrive\$TSFolder" | Select ID, Version, PSChildName | Out-GridView -PassThru

$TSID = $TSProperty.ID
$NewTSID = ($TSID -replace "([0-9]+)","") + ([int]("$TSID" -replace "([a-zA-Z]+)","") + 1).ToString("000")

$TSVersion = $TSProperty.Version
[string]$NewTSVersion = ([int]$TSVersion.replace(".","") + 1)
$NewTSVersion = $NewTSVersion.Substring(0,$NewTSVersion.Length-1) + "." + $NewTSVersion.Substring($NewTSVersion.Length-1)

$TSName = ($TSProperty.PSChildName).substring(0,($TSProperty.PSChildName).length-3) + $NewTSVersion

# Set location to PSDrive location
Set-Location $PSdrive

# Create New Task Sequence, based on selected Out-Gridview Task Sequence
If (Test-Path "$PhysicalPath\Control\$NewTSID") {
    Write-Output "Folder already exists, please manually remove or replace $PhysicalPath\Control\$NewTSID"
    Read-Host "Press enter to continue"
}

If (-NOT (Test-Path "$PhysicalPath\Control\$NewTSID")) {
    Import-MDTTaskSequence -Path $TSFolder -Name $TSName -Template $TSTemplate -ID $NewTSID -Version $NewTSVersion
    COPY "$PhysicalPath\Control\$TSID\*.xml" "$PhysicalPath\Control\$NewTSID"
}

Else {
    Write-Warning "Folder still exists, task sequence not created. Aborting script..."
}

# End of script